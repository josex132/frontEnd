package com.educativo.apiaulapoo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Configuración CORS — permite que el frontend se conecte a la API.
 *
 * Orígenes habilitados:
 *   http://localhost:5500  / http://127.0.0.1:5500  → Live Server de VS Code
 *   http://localhost:5501  / http://127.0.0.1:5501  → Live Server puerto alternativo
 *   http://localhost:3000  / http://127.0.0.1:3000  → React / Node dev server
 *   http://localhost       / http://127.0.0.1        → Apache / XAMPP
 *   http://localhost:8080                            → mismo servidor
 *
 * IMPORTANTE: abre los HTML con Live Server (puerto 5500), no con
 * doble clic (file://). Los navegadores bloquean fetch() desde file://.
 */
@Configuration
public class CorsConfig {

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins(
                                "http://localhost:5500",
                                "http://127.0.0.1:5500",
                                "http://localhost:5501",
                                "http://127.0.0.1:5501",
                                "http://localhost:3000",
                                "http://127.0.0.1:3000",
                                "http://localhost:8080",
                                "http://localhost",
                                "http://127.0.0.1"
                        )
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
}

