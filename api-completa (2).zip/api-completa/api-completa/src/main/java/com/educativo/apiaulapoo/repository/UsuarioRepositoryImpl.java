package com.educativo.apiaulapoo.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.educativo.apiaulapoo.model.Usuario;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Repositorio de Usuario en memoria con persistencia en JSON.
 *
 * Al arrancar el servidor:
 *   1. Carga los usuarios guardados en data/usuarios.json
 *   2. Si el archivo está vacío (primera vez), inserta los usuarios
 *      de ejemplo (seed) para que el frontend siempre tenga datos.
 *
 * Usuarios seed:
 *   carlos.martinez@gmail.com  / admin123   → Administrador
 *   laura.gomez@gmail.com      / usuario123 → Empleado
 *   andres.torres@gmail.com    / usuario123 → Empleado (inactivo)
 *   sofia.ramirez@gmail.com    / usuario123 → Empleado
 */
@Repository
public class UsuarioRepositoryImpl implements UsuarioRepository {

    private final Map<Long, Usuario> usuarios = new HashMap<>();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Path archivoUsuarios = Paths.get("data", "usuarios.json");

    @PostConstruct
    public void inicializar() {
        cargarDesdeArchivo();
        insertarSeedSiVacio();
    }

    // ── Datos de ejemplo ─────────────────────────────────────────────────────
    /**
     * Inserta usuarios de ejemplo SOLO si no hay ninguno guardado.
     * Así siempre hay datos para el frontend aunque sea la primera ejecución.
     */
    private void insertarSeedSiVacio() {
        if (!usuarios.isEmpty()) return;

        guardar(new Usuario(null, "Carlos Martínez", "carlos.martinez@gmail.com",
                32, "Administrador", true,  "admin123"));
        guardar(new Usuario(null, "Laura Gómez",     "laura.gomez@gmail.com",
                27, "Empleado",      true,  "usuario123"));
        guardar(new Usuario(null, "Andrés Torres",   "andres.torres@gmail.com",
                35, "Empleado",      false, "usuario123"));
        guardar(new Usuario(null, "Sofía Ramírez",   "sofia.ramirez@gmail.com",
                29, "Empleado",      true,  "usuario123"));
    }

    // ── CRUD ─────────────────────────────────────────────────────────────────

    @Override
    public synchronized Usuario guardar(Usuario usuario) {
        Long nuevoId = IdGenerator.generarIdUsuario();
        usuario.setId(nuevoId);
        usuarios.put(nuevoId, usuario);
        guardarEnArchivo();
        return usuario;
    }

    @Override
    public synchronized Optional<Usuario> buscarPorId(Long id) {
        return Optional.ofNullable(usuarios.get(id));
    }

    @Override
    public synchronized List<Usuario> obtenerTodos() {
        return List.copyOf(usuarios.values());
    }

    @Override
    public synchronized Usuario actualizar(Long id, Usuario usuario) {
        usuario.setId(id);
        usuarios.put(id, usuario);
        guardarEnArchivo();
        return usuario;
    }

    @Override
    public synchronized boolean eliminar(Long id) {
        boolean eliminado = usuarios.remove(id) != null;
        if (eliminado) guardarEnArchivo();
        return eliminado;
    }

    // ── Persistencia JSON ────────────────────────────────────────────────────

    private void cargarDesdeArchivo() {
        try {
            if (Files.notExists(archivoUsuarios)) {
                Files.createDirectories(archivoUsuarios.getParent());
                Files.createFile(archivoUsuarios);
                guardarEnArchivo();
                return;
            }
            if (Files.size(archivoUsuarios) == 0) {
                guardarEnArchivo();
                return;
            }

            List<Usuario> cargados = objectMapper.readValue(
                    archivoUsuarios.toFile(),
                    new TypeReference<List<Usuario>>() {}
            );
            for (Usuario u : cargados) {
                if (u.getId() != null) usuarios.put(u.getId(), u);
            }

            long siguienteId = usuarios.keySet().stream()
                    .max(Comparator.naturalOrder()).orElse(0L) + 1;
            IdGenerator.setSiguienteIdUsuario(siguienteId);

        } catch (IOException e) {
            throw new IllegalStateException("No se pudo cargar usuarios.json", e);
        }
    }

    private void guardarEnArchivo() {
        try {
            Files.createDirectories(archivoUsuarios.getParent());
            objectMapper.writerWithDefaultPrettyPrinter()
                        .writeValue(archivoUsuarios.toFile(), usuarios.values());
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo guardar usuarios.json", e);
        }
    }
}
