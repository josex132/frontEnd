package com.educativo.apiaulapoo.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.educativo.apiaulapoo.model.Producto;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Repositorio de Producto en memoria con persistencia en JSON.
 *
 * Al arrancar el servidor:
 *   1. Carga los productos guardados en data/productos.json
 *   2. Si el archivo está vacío (primera vez), inserta los productos
 *      de ejemplo (seed) para que el frontend siempre tenga datos.
 */
@Repository
public class ProductoRepositoryImpl implements ProductoRepository {

    private final Map<Long, Producto> productos = new HashMap<>();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Path archivoProductos = Paths.get("data", "productos.json");

    @PostConstruct
    public void inicializar() {
        cargarDesdeArchivo();
        insertarSeedSiVacio();
    }

    // ── Datos de ejemplo ─────────────────────────────────────────────────────
    /**
     * Inserta productos de ejemplo SOLO si no hay ninguno guardado.
     * Así siempre hay datos para el frontend aunque sea la primera ejecución.
     */
    private void insertarSeedSiVacio() {
        if (!productos.isEmpty()) return;

        guardar(new Producto(null, "Balón de Fútbol",   85000,  25, "Fútbol"));
        guardar(new Producto(null, "Raqueta de Tenis",  220000,  8, "Tenis"));
        guardar(new Producto(null, "Zapatos Running",   310000, 15, "Running"));
        guardar(new Producto(null, "Gafas Natación",     45000, 30, "Natación"));
        guardar(new Producto(null, "Guantes Boxeo",     130000,  6, "Boxeo"));
        guardar(new Producto(null, "Bicicleta MTB",     850000, 12, "Ciclismo"));
    }

    // ── CRUD ─────────────────────────────────────────────────────────────────

    @Override
    public synchronized Producto guardar(Producto producto) {
        Long nuevoId = IdGenerator.generarIdProducto();
        producto.setId(nuevoId);
        productos.put(nuevoId, producto);
        guardarEnArchivo();
        return producto;
    }

    @Override
    public synchronized Optional<Producto> buscarPorId(Long id) {
        return Optional.ofNullable(productos.get(id));
    }

    @Override
    public synchronized List<Producto> obtenerTodos() {
        return List.copyOf(productos.values());
    }

    @Override
    public synchronized Producto actualizar(Long id, Producto producto) {
        producto.setId(id);
        productos.put(id, producto);
        guardarEnArchivo();
        return producto;
    }

    @Override
    public synchronized boolean eliminar(Long id) {
        boolean eliminado = productos.remove(id) != null;
        if (eliminado) guardarEnArchivo();
        return eliminado;
    }

    // ── Persistencia JSON ────────────────────────────────────────────────────

    private void cargarDesdeArchivo() {
        try {
            if (Files.notExists(archivoProductos)) {
                Files.createDirectories(archivoProductos.getParent());
                Files.createFile(archivoProductos);
                guardarEnArchivo();
                return;
            }
            if (Files.size(archivoProductos) == 0) {
                guardarEnArchivo();
                return;
            }

            List<Producto> cargados = objectMapper.readValue(
                    archivoProductos.toFile(),
                    new TypeReference<List<Producto>>() {}
            );
            for (Producto p : cargados) {
                if (p.getId() != null) productos.put(p.getId(), p);
            }

            long siguienteId = productos.keySet().stream()
                    .max(Comparator.naturalOrder()).orElse(0L) + 1;
            IdGenerator.setSiguienteIdProducto(siguienteId);

        } catch (IOException e) {
            throw new IllegalStateException("No se pudo cargar productos.json", e);
        }
    }

    private void guardarEnArchivo() {
        try {
            Files.createDirectories(archivoProductos.getParent());
            objectMapper.writerWithDefaultPrettyPrinter()
                        .writeValue(archivoProductos.toFile(), productos.values());
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo guardar productos.json", e);
        }
    }
}
